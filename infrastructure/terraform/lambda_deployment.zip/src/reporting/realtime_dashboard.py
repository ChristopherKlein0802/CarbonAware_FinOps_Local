"""
Real-time dashboard for Carbon-Aware FinOps metrics.
"""

import dash
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output
import plotly.graph_objects as go
import pandas as pd
import boto3
import os
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class CarbonFinOpsDashboard:
    """Real-time dashboard for Carbon-Aware FinOps metrics."""

    def __init__(self, aws_profile=None):
        self.app = dash.Dash(__name__)
        self.aws_profile = aws_profile or os.getenv('AWS_PROFILE', 'carbon-finops-sandbox')

        try:
            # Create session with SSO profile
            session = boto3.Session(profile_name=self.aws_profile)
            
            self.dynamodb = session.resource('dynamodb')
            self.cloudwatch = session.client('cloudwatch')
            self.ce = session.client('ce')
            self.ec2 = session.client('ec2')
            
            logger.info(f"AWS clients initialized successfully with profile: {self.aws_profile}")
        except Exception as e:
            logger.warning(f"AWS clients initialization failed with profile '{self.aws_profile}': {e}")
            logger.info("Please run: aws sso login --profile carbon-finops-sandbox")
            # Initialize as None to handle offline mode
            self.dynamodb = None
            self.cloudwatch = None
            self.ce = None
            self.ec2 = None

        # Initialize layou
        self.setup_layout()
        self.setup_callbacks()

    def setup_layout(self):
        """Setup dashboard layout."""

        self.app.layout = html.Div([
            html.Div([
                html.H1("Carbon-Aware FinOps Dashboard",
                       style={'textAlign': 'center', 'color': '#2c3e50'}),
                html.Hr(),
            ]),

            # KPI Cards Row
            html.Div([
                html.Div([
                    html.Div([
                        html.H3("Cost Savings", style={'color': '#27ae60'}),
                        html.H2(id='cost-savings', children='$0'),
                        html.P('This Month', style={'color': '#7f8c8d'})
                    ], className='kpi-card'),
                ], className='four columns'),

                html.Div([
                    html.Div([
                        html.H3("CO₂ Reduction", style={'color': '#2ecc71'}),
                        html.H2(id='carbon-reduction', children='0 kg'),
                        html.P('This Month', style={'color': '#7f8c8d'})
                    ], className='kpi-card'),
                ], className='four columns'),

                html.Div([
                    html.Div([
                        html.H3("Optimized Instances", style={'color': '#3498db'}),
                        html.H2(id='optimized-instances', children='0'),
                        html.P('Active Now', style={'color': '#7f8c8d'})
                    ], className='kpi-card'),
                ], className='four columns'),
            ], className='row'),

            # Charts Row
            html.Div([
                html.Div([
                    dcc.Graph(id='cost-timeline'),
                ], className='six columns'),

                html.Div([
                    dcc.Graph(id='carbon-timeline'),
                ], className='six columns'),
            ], className='row'),

            # Recommendations Table
            html.Div([
                html.H3("Active Recommendations"),
                html.Div(id='recommendations-table')
            ], style={'margin': '20px'}),

            # Instance Status
            html.Div([
                html.H3("Instance Status"),
                dcc.Graph(id='instance-status-chart')
            ], style={'margin': '20px'}),

            # Auto-refresh
            dcc.Interval(
                id='interval-component',
                interval=60 * 1000,  # Update every minute
                n_intervals=0
            )
        ])

    def setup_callbacks(self):
        """Setup dashboard callbacks."""

        @self.app.callback(
            [Output('cost-savings', 'children'),
             Output('carbon-reduction', 'children'),
             Output('optimized-instances', 'children'),
             Output('cost-timeline', 'figure'),
             Output('carbon-timeline', 'figure'),
             Output('recommendations-table', 'children'),
             Output('instance-status-chart', 'figure')],
            [Input('interval-component', 'n_intervals')]
        )
        def update_dashboard(_):
            # Get current metrics
            metrics = self.get_current_metrics()

            # Update KPIs
            cost_savings = f"${metrics['cost_savings']:.2f}"
            carbon_reduction = f"{metrics['carbon_reduction']:.1f} kg"
            optimized_count = str(metrics['optimized_instances'])

            # Create timeline charts
            cost_fig = self.create_cost_timeline()
            carbon_fig = self.create_carbon_timeline()

            # Create recommendations table
            recommendations_table = self.create_recommendations_table()

            # Create instance status char
            status_fig = self.create_instance_status_chart()

            return (cost_savings, carbon_reduction, optimized_count,
                   cost_fig, carbon_fig, recommendations_table, status_fig)

    def get_current_metrics(self):
        """Get current metrics from DynamoDB and CloudWatch."""

        # Default values for offline mode
        default_metrics = {
            'cost_savings': 0,
            'carbon_reduction': 0,
            'optimized_instances': 0,
            'total_shutdowns': 0,
            'total_startups': 0
        }

        if not self.dynamodb:
            return default_metrics

        try:
            # Get data from DynamoDB
            table = self.dynamodb.Table('carbon-aware-finops-state')

            # Query last 30 days
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)

            response = table.scan(
                FilterExpression='#t >= :start',
                ExpressionAttributeNames={'#t': 'timestamp'},
                ExpressionAttributeValues={':start': int(start_date.timestamp())}
            )

            # Calculate metrics
            total_shutdowns = sum(item.get('shutdowns', 0) for item in response.get('Items', []))
            total_startups = sum(item.get('startups', 0) for item in response.get('Items', []))

            # Estimate savings (simplified)
            cost_per_hour = 0.05  # Average cost per instance hour
            carbon_per_hour = 0.2  # kg CO2 per instance hour

            hours_saved = total_shutdowns * 8

            return {
                'cost_savings': hours_saved * cost_per_hour,
                'carbon_reduction': hours_saved * carbon_per_hour,
                'optimized_instances': total_shutdowns,
                'total_shutdowns': total_shutdowns,
                'total_startups': total_startups
            }
        except Exception as e:
            logger.error(f"Error getting metrics: {e}")
            return default_metrics

    def create_cost_timeline(self):
        """Create cost timeline chart."""

        if not self.ce:
            # Return empty chart if no AWS connection
            fig = go.Figure()
            fig.update_layout(
                title='Cost Data - AWS Connection Required',
                xaxis_title='Date',
                yaxis_title='Cost ($)',
                annotations=[
                    dict(
                        text="Please ensure AWS SSO is logged in to view cost data",
                        xref="paper", yref="paper",
                        x=0.5, y=0.5, xanchor='center', yanchor='middle',
                        showarrow=False, font=dict(size=16)
                    )
                ]
            )
            return fig

        # Get cost data from Cost Explorer
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')

        try:
            response = self.ce.get_cost_and_usage(
                TimePeriod={'Start': start_date, 'End': end_date},
                Granularity='DAILY',
                Metrics=['UnblendedCost'],
                Filter={
                    'Tags': {
                        'Key': 'Project',
                        'Values': ['carbon-aware-finops']
                    }
                }
            )

            dates = [r['TimePeriod']['Start'] for r in response['ResultsByTime']]
            costs = [float(r['Total']['UnblendedCost']['Amount']) for r in response['ResultsByTime']]

            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=dates, y=costs,
                mode='lines+markers',
                name='Daily Cost',
                line=dict(color='#e74c3c', width=2)
            ))

            fig.update_layout(
                title='Cost Trend (Last 30 Days)',
                xaxis_title='Date',
                yaxis_title='Cost ($)',
                hovermode='x unified'
            )

            return fig

        except Exception as e:
            logger.error(f"Error creating cost timeline: {e}")
            # Return empty figure on error
            return go.Figure()

    def create_carbon_timeline(self):
        """Create carbon emissions timeline chart."""

        if not self.dynamodb:
            # Return empty chart if no AWS connection
            fig = go.Figure()
            fig.update_layout(
                title='Carbon Emissions Data - AWS Connection Required',
                xaxis_title='Date',
                yaxis_title='CO₂ (kg)',
                annotations=[
                    dict(
                        text="Please ensure AWS SSO is logged in to view carbon data",
                        xref="paper", yref="paper",
                        x=0.5, y=0.5, xanchor='center', yanchor='middle',
                        showarrow=False, font=dict(size=16)
                    )
                ]
            )
            return fig

        try:
            # Get real carbon data from DynamoDB
            table = self.dynamodb.Table('carbon-aware-finops-state')
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)

            response = table.scan(
                FilterExpression='#t >= :start',
                ExpressionAttributeNames={'#t': 'timestamp'},
                ExpressionAttributeValues={':start': int(start_date.timestamp())}
            )

            if not response.get('Items'):
                # No data available
                fig = go.Figure()
                fig.update_layout(
                    title='Carbon Emissions Data - No Data Available',
                    xaxis_title='Date',
                    yaxis_title='CO₂ (kg)',
                    annotations=[
                        dict(
                            text="No carbon emissions data found. Run carbon-aware scheduling to collect data.",
                            xref="paper", yref="paper",
                            x=0.5, y=0.5, xanchor='center', yanchor='middle',
                            showarrow=False, font=dict(size=14)
                        )
                    ]
                )
                return fig

            # Process real data
            carbon_data = []
            for item in response['Items']:
                if 'carbon_intensity' in item:
                    carbon_data.append({
                        'timestamp': datetime.fromtimestamp(item['timestamp']),
                        'carbon_intensity': float(item.get('carbon_intensity', 0))
                    })

            if carbon_data:
                df = pd.DataFrame(carbon_data)
                df = df.sort_values('timestamp')
                
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=df['timestamp'], 
                    y=df['carbon_intensity'],
                    mode='lines+markers',
                    name='Carbon Intensity',
                    line=dict(color='#27ae60')
                ))

                fig.update_layout(
                    title='Real Carbon Intensity Data',
                    xaxis_title='Date',
                    yaxis_title='Carbon Intensity (gCO₂/kWh)',
                    hovermode='x unified'
                )
                return fig

        except Exception as e:
            logger.error(f"Error getting carbon timeline data: {e}")

        # Fallback empty chart with specific error handling
        fig = go.Figure()
        if "ResourceNotFoundException" in str(e):
            fig.update_layout(
                title='Carbon Data Setup Required',
                xaxis_title='Date',
                yaxis_title='CO₂ (kg)',
                annotations=[
                    dict(
                        text="The carbon data table doesn't exist yet. Deploy DynamoDB tables or run carbon-aware scheduling first.",
                        xref="paper", yref="paper",
                        x=0.5, y=0.5, xanchor='center', yanchor='middle',
                        showarrow=False, font=dict(size=14)
                    )
                ]
            )
        else:
            fig.update_layout(
                title='Carbon Emissions Data - Error Loading Data',
                xaxis_title='Date',
                yaxis_title='CO₂ (kg)',
                annotations=[
                    dict(
                        text=f"Error loading data: {str(e)[:50]}...",
                        xref="paper", yref="paper",
                        x=0.5, y=0.5, xanchor='center', yanchor='middle',
                        showarrow=False, font=dict(size=14)
                    )
                ]
            )
        return fig

    def create_recommendations_table(self):
        """Create recommendations table from real AWS data."""

        if not self.dynamodb:
            return html.Div([
                html.H4("Recommendations - AWS Connection Required"),
                html.P("Please ensure AWS SSO is logged in to view recommendations.")
            ])

        try:
            # Get real recommendations from DynamoDB
            table = self.dynamodb.Table('carbon-aware-finops-rightsizing')
            
            response = table.scan()
            
            if not response.get('Items'):
                return html.Div([
                    html.H4("No Recommendations Available"),
                    html.P("No rightsizing recommendations found. Run the rightsizing Lambda function to generate recommendations.")
                ])

            recommendations = []
            for item in response['Items']:
                if item.get('recommendation', {}).get('action') != 'no_change':
                    rec = item.get('recommendation', {})
                    recommendations.append({
                        'Instance': item.get('instance_id', 'N/A'),
                        'Current': item.get('current_type', 'N/A'),
                        'Recommended': rec.get('recommended_type', 'N/A'),
                        'Savings': f"${rec.get('estimated_monthly_savings', 0):.2f}/month",
                        'Action': rec.get('action', 'N/A').title(),
                        'Reason': ', '.join(rec.get('reason', []))
                    })

            if not recommendations:
                return html.Div([
                    html.H4("No Active Recommendations"),
                    html.P("All instances are optimally sized based on current usage patterns.")
                ])

            df = pd.DataFrame(recommendations)

            return dash_table.DataTable(
                data=df.to_dict('records'),
                columns=[{"name": i, "id": i} for i in df.columns],
                style_cell={'textAlign': 'left'},
                style_data_conditional=[
                    {
                        'if': {'column_id': 'Action', 'filter_query': '{Action} = "Downsize"'},
                        'backgroundColor': '#3498db',
                        'color': 'white',
                    },
                    {
                        'if': {'column_id': 'Action', 'filter_query': '{Action} = "Upsize"'},
                        'backgroundColor': '#e67e22',
                        'color': 'white',
                    },
                    {
                        'if': {'column_id': 'Action', 'filter_query': '{Action} = "Convert to spot"'},
                        'backgroundColor': '#9b59b6',
                        'color': 'white',
                    }
                ]
            )

        except Exception as e:
            logger.error(f"Error getting recommendations: {e}")
            
            # Handle specific DynamoDB table not found error
            if "ResourceNotFoundException" in str(e):
                return html.Div([
                    html.H4("Recommendations Setup Required"),
                    html.P("The rightsizing recommendations table doesn't exist yet."),
                    html.P("Please deploy the DynamoDB tables first or run the rightsizing Lambda function to create the table.")
                ])
            else:
                return html.Div([
                    html.H4("Error Loading Recommendations"),
                    html.P(f"Failed to load recommendations: {str(e)}")
                ])

    def create_instance_status_chart(self):
        """Create instance status pie chart."""

        if not self.ec2:
            # Return empty chart with message
            fig = go.Figure()
            fig.update_layout(
                title='Instance Status - AWS Connection Required',
                annotations=[
                    dict(
                        text="Please ensure AWS SSO is logged in to view instance status",
                        xref="paper", yref="paper",
                        x=0.5, y=0.5, xanchor='center', yanchor='middle',
                        showarrow=False, font=dict(size=16)
                    )
                ]
            )
            return fig
        else:
            try:
                # Get current instance states
                response = self.ec2.describe_instances(
                    Filters=[
                        {'Name': 'tag:Project', 'Values': ['carbon-aware-finops']}
                    ]
                )

                status_counts = {'running': 0, 'stopped': 0, 'pending': 0, 'stopping': 0}

                for reservation in response['Reservations']:
                    for instance in reservation['Instances']:
                        state = instance['State']['Name']
                        if state in status_counts:
                            status_counts[state] += 1
            except Exception as e:
                logger.error(f"Error getting instance status: {e}")
                status_counts = {'running': 0, 'stopped': 0}

        fig = go.Figure(data=[go.Pie(
            labels=list(status_counts.keys()),
            values=list(status_counts.values()),
            hole=.3
        )])

        fig.update_layout(
            title='Current Instance Status',
            annotations=[dict(text='Instances', x=0.5, y=0.5, font_size=20, showarrow=False)]
        )

        return fig

    def run(self, debug=True, port=8050, host='127.0.0.1'):
        """Run the dashboard."""
        print(f"🚀 Starting dashboard at http://{host}:{port}")
        print("Press Ctrl+C to stop")
        self.app.run_server(debug=debug, port=port, host=host)


def main():
    """Main entry point for the dashboard."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    dashboard = CarbonFinOpsDashboard()
    dashboard.run()




if __name__ == "__main__":
    main()
